#pragma once
#include <atomic>
#include <cstdint>
#include <ctime>
#include <future>
#include <memory>
#include <set>
#include <string>
#include <vector>
namespace sfm {
struct Entry { std::string name; bool directory=false; uint64_t size=0; time_t modified=0; };
struct Listing { std::vector<Entry> entries; std::string error; uint64_t total=0, free=0; };
class Storage {
public:
 virtual ~Storage()=default;
 virtual Listing list(const std::string&, const std::atomic_bool&) const=0;
};
class LocalStorage final: public Storage {
 std::string root_;
public:
 explicit LocalStorage(std::string root):root_(std::move(root)){}
 Listing list(const std::string&,const std::atomic_bool&) const override;
};
bool validPath(const std::string&);
std::string childPath(const std::string&,const std::string&);
std::string parentPath(const std::string&);
class Panel {
 std::shared_ptr<Storage> storage_;
 std::future<Listing> pending_;
 std::atomic_bool cancel_{false};
 std::string requested_;
public:
 std::string path="/", error;
 Listing listing;
 size_t cursor=0, scroll=0;
 std::set<std::string> selected;
 bool loading=false;
 explicit Panel(std::shared_ptr<Storage> s):storage_(std::move(s)){}
 ~Panel();
 void load(std::string);
 bool poll();
 void move(int);
 void toggle();
 void enter();
 void up();
 void reveal();
};
}
