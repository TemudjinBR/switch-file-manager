#pragma once
#include "browser.hpp"
#include <SDL.h>
#include <SDL_ttf.h>
namespace sfm {
class Ui {
 SDL_Renderer* r_; TTF_Font* font_; TTF_Font* small_;
 void box(int,int,int,int,SDL_Color,int radius=0);
 void text(const std::string&,int,int,SDL_Color,int width=0,bool small=false);
 void marquee(const std::string&,int,int,int,SDL_Color);
 void pane(const Panel&,int,bool);
public:
 Ui(SDL_Renderer*r,TTF_Font*f,TTF_Font*s):r_(r),font_(f),small_(s){}
 void draw(const Panel&,const Panel&,int);
};
}
