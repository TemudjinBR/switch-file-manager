#include "sfm/ui.hpp"
#include <cstdio>
#ifdef __SWITCH__
#include <switch.h>
#endif
int main(int argc,char**argv){
#ifdef __SWITCH__
 (void)argc;(void)argv;
 const std::string root="sdmc:";
 padConfigureInput(1,HidNpadStyleSet_NpadStandard);PadState pad;padInitializeDefault(&pad);hidInitializeTouchScreen();
 if(R_FAILED(plInitialize(PlServiceType_User)))return 1;
 PlFontData fd{};if(R_FAILED(plGetSharedFontByType(&fd,PlSharedFontType_Standard))){plExit();return 1;}
#else
 const std::string root=argc>1?argv[1]:".";
#endif
 if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_EVENTS)!=0)return 2;
 if(TTF_Init()!=0){SDL_Quit();return 3;}
 auto*window=SDL_CreateWindow("Switch File Manager",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,1280,720,0);
 auto*renderer=window?SDL_CreateRenderer(window,-1,SDL_RENDERER_SOFTWARE):nullptr;
 if(!renderer){TTF_Quit();SDL_Quit();return 4;}
 SDL_RenderSetLogicalSize(renderer,1280,720);
#ifdef __SWITCH__
 auto*font=TTF_OpenFontRW(SDL_RWFromConstMem(fd.address,fd.size),1,26);
 auto*small=TTF_OpenFontRW(SDL_RWFromConstMem(fd.address,fd.size),1,18);
#else
 auto*font=TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",26);
 auto*small=TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",18);
#endif
 if(!font||!small){fprintf(stderr,"Fonte indisponível: %s\n",TTF_GetError());return 5;}
 {
 auto storage=std::make_shared<sfm::LocalStorage>(root);sfm::Panel left(storage),right(storage);left.load("/");right.load("/");
 sfm::Ui ui(renderer,font,small);int active=0;bool running=true;bool dirty=true;uint32_t last=0,repeatAt=0;int repeatDir=0;
 auto touch=[&](int x,int y){if(x<24||x>=1256)return;active=x>=650?1:0;auto&p=active?right:left;if(y>=244&&y<554&&!p.loading){size_t idx=p.scroll+(y-244)/31;if(idx<p.listing.entries.size()){if(p.cursor==idx)p.enter();else{p.cursor=idx;p.reveal();}}}else if(y>=666){if(x<140)p.enter();else if(x<260)p.up();else if(x<430)p.toggle();else if(x<600)active=1-active;else if(x<820)p.load(p.path);else if(x<1020)p.load("/");else running=false;}dirty=true;};
 while(running){
#ifdef __SWITCH__
 if(!appletMainLoop())break;
 padUpdate(&pad);u64 down=padGetButtonsDown(&pad),held=padGetButtons(&pad);auto&p=active?right:left;
 if(down&HidNpadButton_Plus)running=false;
 if(down&(HidNpadButton_L|HidNpadButton_R)){active=1-active;dirty=true;continue;}
 if(down&HidNpadButton_A)p.enter();
 if(down&HidNpadButton_B)p.up();
 if(down&HidNpadButton_X)p.toggle();
 if(down&HidNpadButton_Y)p.load(p.path);
 if(down&HidNpadButton_Minus)p.load("/");
 int dir=(held&HidNpadButton_AnyDown)?1:(held&HidNpadButton_AnyUp)?-1:0;uint32_t now=SDL_GetTicks();if(dir&&(dir!=repeatDir||now>=repeatAt)){p.move(dir);repeatAt=now+(dir!=repeatDir?350:80);dirty=true;}repeatDir=dir;
 if(down&HidNpadButton_ZL)p.move(-10);
 if(down&HidNpadButton_ZR)p.move(10);
 if(down)dirty=true;
 HidTouchScreenState ts{};static bool wasTouch=false;hidGetTouchScreenStates(&ts,1);if(ts.count&&!wasTouch)touch(ts.touches[0].x,ts.touches[0].y);wasTouch=ts.count>0;
#else
 (void)repeatAt;(void)repeatDir;
#endif
 SDL_Event e;while(SDL_PollEvent(&e)){auto&p=active?right:left;if(e.type==SDL_QUIT)running=false;
#ifndef __SWITCH__
 if(e.type==SDL_MOUSEBUTTONDOWN)touch(e.button.x,e.button.y);
#endif
 if(e.type==SDL_MOUSEWHEEL)p.move(-e.wheel.y*3);
 if(e.type==SDL_KEYDOWN){switch(e.key.keysym.sym){case SDLK_ESCAPE:running=false;break;case SDLK_TAB:active=1-active;break;case SDLK_UP:p.move(-1);break;case SDLK_DOWN:p.move(1);break;case SDLK_PAGEUP:p.move(-10);break;case SDLK_PAGEDOWN:p.move(10);break;case SDLK_RETURN:p.enter();break;case SDLK_BACKSPACE:p.up();break;case SDLK_SPACE:p.toggle();break;case SDLK_F5:p.load(p.path);break;case SDLK_HOME:p.load("/");break;default:break;}}dirty=true;}
 dirty=left.poll()||dirty;dirty=right.poll()||dirty;
 if(dirty||SDL_GetTicks()-last>100){ui.draw(left,right,active);last=SDL_GetTicks();dirty=false;}
#ifndef __SWITCH__
 if(argc>2&&std::string(argv[2])=="--screenshot"&&!left.loading&&!right.loading){auto*s=SDL_CreateRGBSurfaceWithFormat(0,1280,720,32,SDL_PIXELFORMAT_ARGB8888);if(s){SDL_RenderReadPixels(renderer,nullptr,s->format->format,s->pixels,s->pitch);SDL_SaveBMP(s,"preview.bmp");SDL_FreeSurface(s);}running=false;}
#endif
 SDL_Delay(16);
 }
 }
 TTF_CloseFont(small);TTF_CloseFont(font);SDL_DestroyRenderer(renderer);SDL_DestroyWindow(window);TTF_Quit();SDL_Quit();
#ifdef __SWITCH__
 plExit();
#endif
 return 0;
}
