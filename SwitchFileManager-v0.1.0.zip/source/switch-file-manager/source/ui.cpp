#include "sfm/ui.hpp"
#include <algorithm>
#include <cstdio>
namespace sfm {
namespace {
constexpr SDL_Color bg{10,18,33,255},card{17,29,47,255},line{36,55,77,255},cyan{61,219,224,255},white{229,239,249,255},muted{143,165,186,255};
std::string bytes(uint64_t n){char b[40];if(n>=1073741824)snprintf(b,sizeof b,"%.1f GB",double(n)/1073741824);else if(n>=1048576)snprintf(b,sizeof b,"%.1f MB",double(n)/1048576);else if(n>=1024)snprintf(b,sizeof b,"%.1f KB",double(n)/1024);else snprintf(b,sizeof b,"%llu B",static_cast<unsigned long long>(n));return b;}
std::string date(time_t t){char b[20];tm* v=localtime(&t);if(!v)return "—";strftime(b,sizeof b,"%d/%m/%y",v);return b;}
}
void Ui::box(int x,int y,int w,int h,SDL_Color c,int radius){SDL_SetRenderDrawColor(r_,c.r,c.g,c.b,c.a);SDL_Rect a{x+radius,y,w-2*radius,h};SDL_RenderFillRect(r_,&a);a={x,y+radius,w,h-2*radius};SDL_RenderFillRect(r_,&a);for(int i=0;i<radius;i++){int dx=radius-i;int dy=0;while((dy+1)*(dy+1)+dx*dx<=radius*radius)++dy;SDL_RenderDrawLine(r_,x+i,y+radius-dy,x+i,y+h-radius+dy-1);SDL_RenderDrawLine(r_,x+w-i-1,y+radius-dy,x+w-i-1,y+h-radius+dy-1);}}
void Ui::text(const std::string& s,int x,int y,SDL_Color c,int width,bool small){
 if(s.empty())return;
 TTF_Font*f=small?small_:font_;std::string clipped=s;
 int tw=0,th=0;TTF_SizeUTF8(f,clipped.c_str(),&tw,&th);
 while(width>0&&tw>width&&!clipped.empty()) {auto i=clipped.size()-1;while(i>0&&(static_cast<unsigned char>(clipped[i])&0xc0)==0x80)--i;clipped.resize(i);TTF_SizeUTF8(f,(clipped+"…").c_str(),&tw,&th);}
 if(clipped!=s)clipped+="…";
 SDL_Surface*srf=TTF_RenderUTF8_Blended(f,clipped.c_str(),c);if(!srf)return;
 SDL_Texture*t=SDL_CreateTextureFromSurface(r_,srf);SDL_Rect dst{x,y,srf->w,srf->h};if(t){SDL_RenderCopy(r_,t,nullptr,&dst);SDL_DestroyTexture(t);}SDL_FreeSurface(srf);
}
void Ui::marquee(const std::string&s,int x,int y,int width,SDL_Color color){
 int w=0,h=0;TTF_SizeUTF8(small_,s.c_str(),&w,&h);
 int offset=0;if(w>width){const int distance=w-width;int t=int((SDL_GetTicks()/40)%(2*distance+160));offset=std::min(distance,std::max(0,t-80));if(t>distance+80)offset=std::max(0,2*distance+80-t);}
 SDL_Rect clip{x,y,width,25};SDL_RenderSetClipRect(r_,&clip);text(s,x-offset,y,color,0,true);SDL_RenderSetClipRect(r_,nullptr);
}
void Ui::pane(const Panel&p,int x,bool active){
 box(x,108,606,496,active?cyan:line,12);box(x+2,110,602,492,card,10);
 text("microSD",x+20,126,white);text(active?"PAINEL ATIVO":"PAINEL SECUNDÁRIO",x+350,130,active?cyan:muted,235,true);
 marquee("sdmc:"+p.path,x+20,162,565,cyan);
 box(x+16,199,574,1,line);text("NOME",x+52,210,muted,0,true);text("TAM.",x+303,210,muted,0,true);text("TIPO",x+401,210,muted,0,true);text("DATA",x+483,210,muted,0,true);
 for(size_t row=0;row<10&&p.scroll+row<p.listing.entries.size();++row){
  const size_t idx=p.scroll+row;const auto&e=p.listing.entries[idx];int y=244+int(row)*31;
  if(idx==p.cursor)box(x+10,y-2,584,30,active?SDL_Color{29,69,87,255}:SDL_Color{31,45,63,255},5);
  if(p.selected.count(e.name))box(x+14,y+7,6,6,cyan,2);
  box(x+28,y+7,15,12,e.directory?cyan:muted,2);if(e.directory)box(x+28,y+4,7,5,cyan,1);
  text(e.name,x+52,y,e.directory?white:muted,239,true);
  text(e.directory?"—":bytes(e.size),x+303,y,muted,92,true);
  auto dot=e.name.find_last_of('.');std::string type=e.directory?"Pasta":(dot!=std::string::npos?e.name.substr(dot+1):"Arquivo");
  text(type,x+401,y,muted,74,true);text(date(e.modified),x+483,y,muted,100,true);
 }
 if(p.loading)text("Lendo pasta…",x+24,555,cyan,550,true);
 else if(!p.error.empty())text(p.error,x+24,555,{255,170,130,255},550,true);
 else text(std::to_string(p.listing.entries.size())+" itens   •   "+std::to_string(p.selected.size())+" selecionados",x+24,555,muted,550,true);
 if(!p.loading&&!p.listing.entries.empty())marquee(p.listing.entries[p.cursor].name,x+24,578,550,white);
 if(p.listing.entries.size()>10){int sy=246+int(286.0*p.scroll/p.listing.entries.size());box(x+593,sy,3,std::max(8,int(2860.0/p.listing.entries.size())),cyan,1);}
 box(x+16,613,574,5,line,2);
 if(p.listing.total){int used=int(574.0*(p.listing.total-p.listing.free)/p.listing.total);box(x+16,613,used,5,cyan,2);text(bytes(p.listing.free)+" livres de "+bytes(p.listing.total),x+18,628,muted,570,true);}
 else text("Capacidade indisponível",x+18,628,muted,570,true);
}
void Ui::draw(const Panel&a,const Panel&b,int active){
 SDL_SetRenderDrawColor(r_,bg.r,bg.g,bg.b,255);SDL_RenderClear(r_);
 box(24,26,42,42,cyan,10);box(33,37,10,20,bg,2);box(47,37,10,20,bg,2);
 text("Switch File Manager",82,22,white);text("Seus arquivos. Dois painéis. Um lugar.",82,59,muted,0,true);
 text("v0.1.0  •  Somente leitura",963,43,cyan,300,true);
 pane(a,24,active==0);pane(b,650,active==1);
 box(0,666,1280,54,card);
 const char* labels[]={"A  Abrir","B  Subir","X  Selecionar","L/R  Painel","Y  Atualizar","−  Raiz","+  Sair"};
 const int starts[]={24,140,260,430,600,820,1020};
 for(int i=0;i<7;++i)text(labels[i],starts[i]+4,682,white,0,true);
 SDL_RenderPresent(r_);
}
}
