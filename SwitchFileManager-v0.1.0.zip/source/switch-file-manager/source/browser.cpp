#include "sfm/browser.hpp"
#include <algorithm>
#include <cerrno>
#include <cstring>
#include <exception>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
namespace sfm {
bool validPath(const std::string& p) {
 if(p.empty()||p[0]!='/'||p.find('\0')!=std::string::npos||p.find('\\')!=std::string::npos) return false;
 size_t a=1;
 while(a<p.size()) { auto b=p.find('/',a); auto part=p.substr(a,b-a); if(part==".."||part=="."||part.empty())return false; if(b==std::string::npos)break; a=b+1; }
 return true;
}
std::string childPath(const std::string& p,const std::string& n){return !p.empty()&&p.back()=='/'?p+n:p+"/"+n;}
std::string parentPath(const std::string& p){auto i=p.find_last_of('/');return i==0?"/":p.substr(0,i);}
Listing LocalStorage::list(const std::string& p,const std::atomic_bool& stop) const {
 Listing out;
 if(!validPath(p)){out.error="Caminho inválido";return out;}
 const std::string full=root_+(p=="/"?"/":p);
 DIR* d=opendir(full.c_str());
 if(!d){out.error="Não foi possível abrir: "+std::string(strerror(errno));return out;}
 while(!stop.load()) {
  errno=0; auto* item=readdir(d);
  if(!item){if(errno)out.error=strerror(errno);break;}
  std::string name=item->d_name;
  if(name=="."||name=="..")continue;
  struct stat st{};
  if(lstat(childPath(full,name).c_str(),&st)!=0){out.error="Falha ao ler metadados: "+name;continue;}
  if(S_ISLNK(st.st_mode))continue; // never follow links outside the provider
  out.entries.push_back({name,S_ISDIR(st.st_mode),static_cast<uint64_t>(st.st_size),st.st_mtime});
 }
 closedir(d);
 if(stop.load()){out.error="Leitura cancelada";return out;}
 std::sort(out.entries.begin(),out.entries.end(),[](const Entry&a,const Entry&b){if(a.directory!=b.directory)return a.directory>b.directory;return a.name<b.name;});
 struct statvfs v{};
 if(statvfs(full.c_str(),&v)==0){out.total=uint64_t(v.f_blocks)*v.f_frsize;out.free=uint64_t(v.f_bavail)*v.f_frsize;}
 return out;
}
Panel::~Panel(){cancel_=true;if(pending_.valid())pending_.wait();}
void Panel::load(std::string p){
 if(loading||!validPath(p))return;
 requested_=std::move(p); cancel_=false;loading=true;error.clear();
 try { pending_=std::async(std::launch::async,[this]{return storage_->list(requested_,cancel_);}); }
 catch(const std::exception&){loading=false;error="Não foi possível iniciar a leitura";}
}
bool Panel::poll(){
 if(!loading||pending_.wait_for(std::chrono::seconds(0))!=std::future_status::ready)return false;
 Listing result;
 try{result=pending_.get();}catch(const std::exception&){loading=false;error="Falha na leitura ou memória insuficiente";return true;}
 loading=false;
 if(!result.error.empty()){error=result.error;return true;}
 listing=std::move(result);path=requested_;cursor=scroll=0;selected.clear();return true;
}
void Panel::reveal(){if(cursor<scroll)scroll=cursor;if(cursor>=scroll+10)scroll=cursor-9;}
void Panel::move(int d){if(loading||listing.entries.empty())return;auto n=static_cast<long long>(cursor)+d;cursor=static_cast<size_t>(std::max(0LL,std::min(n,static_cast<long long>(listing.entries.size()-1))));reveal();}
void Panel::toggle(){if(loading||listing.entries.empty())return;const auto&n=listing.entries[cursor].name;if(!selected.erase(n))selected.insert(n);}
void Panel::enter(){if(loading||listing.entries.empty())return;auto&e=listing.entries[cursor];if(e.directory)load(childPath(path,e.name));}
void Panel::up(){if(!loading&&path!="/")load(parentPath(path));}
}
