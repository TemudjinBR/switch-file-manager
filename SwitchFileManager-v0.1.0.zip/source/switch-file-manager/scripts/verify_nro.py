#!/usr/bin/env python3
"""Structural check, not proof of execution on hardware."""
import pathlib, struct, sys
p=pathlib.Path(sys.argv[1]); data=p.read_bytes()
assert data[16:20]==b'NRO0', 'Missing NRO0 magic'
size=struct.unpack_from('<I',data,24)[0]
assert 0x80<=size<=len(data), 'Invalid NRO image size'
end=0
for offset in (0x20,0x28,0x30):
 start,length=struct.unpack_from('<II',data,offset)
 assert start>=end and start+length<=size, 'Invalid/overlapping segment'
 end=start+length
assert data[size:size+4]==b'ASET', 'Missing assets'
version=struct.unpack_from('<I',data,size+4)[0]
assert version==0
for offset in (size+8,size+24,size+40):
 start,length=struct.unpack_from('<QQ',data,offset)
 if length: assert start>=0x38 and size+start+length<=len(data), 'Invalid asset'
print(f'PASS: NRO0, segment bounds, ASET bounds; {len(data)} bytes. Console not tested.')
