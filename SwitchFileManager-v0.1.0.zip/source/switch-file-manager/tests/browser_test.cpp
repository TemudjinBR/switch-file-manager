#include "sfm/browser.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <thread>
#include <unistd.h>
#include <stdexcept>
namespace fs=std::filesystem;
void finish(sfm::Panel&p){for(int n=0;n<10000&&p.loading;++n){p.poll();std::this_thread::sleep_for(std::chrono::milliseconds(1));}assert(!p.loading);}
struct FailingStorage:sfm::Storage {
 bool exception;
 explicit FailingStorage(bool e):exception(e){}
 sfm::Listing list(const std::string&,const std::atomic_bool&)const override{
  if(exception)throw std::runtime_error("Injected I/O failure");
  sfm::Listing r;r.error="Permissão insuficiente (injetada)";return r;
 }
};
int main(){
 for(bool exception:{false,true}){sfm::Panel p(std::make_shared<FailingStorage>(exception));p.load("/");finish(p);assert(!p.error.empty());assert(p.listing.entries.empty());}

 char temp[]="/tmp/sfm-test-XXXXXX";char*dir=mkdtemp(temp);assert(dir);fs::path root(dir);
 fs::create_directory(root/"vazia");fs::create_directory(root/"ação 日本語");
 std::ofstream(root/"arquivo.txt")<<"dados";std::ofstream(root/".oculto")<<"x";
 fs::create_symlink("/",root/"link");
 auto storage=std::make_shared<sfm::LocalStorage>(root.string());std::atomic_bool stop{false};
 auto a=storage->list("/",stop);assert(a.error.empty());assert(a.entries.size()==4);assert(a.entries[0].directory);assert(a.total>0);
 assert(!sfm::validPath("/../etc"));assert(!sfm::validPath("/a/../../etc"));assert(!sfm::validPath("relative"));assert(!sfm::validPath(std::string("/a\0b",4)));assert(!sfm::validPath("/a\\b"));assert(sfm::validPath("/ação 日本語"));assert(sfm::parentPath("/foo")=="/");
 assert(!storage->list("/../",stop).error.empty());assert(!storage->list("/missing",stop).error.empty());
 sfm::Panel left(storage),right(storage);left.load("/");right.load("/vazia");finish(left);finish(right);assert(right.listing.entries.empty());right.move(1);right.toggle();right.enter();assert(right.cursor==0);
 left.toggle();assert(left.selected.size()==1);left.toggle();assert(left.selected.empty());left.move(500);assert(left.cursor==3);assert(right.path=="/vazia");
 left.load("/missing");finish(left);assert(left.path=="/");assert(!left.error.empty());assert(left.listing.entries.size()==4);
 fs::create_directory(root/"milhares");for(int i=0;i<5000;++i)std::ofstream(root/"milhares"/std::to_string(i));left.load("/milhares");finish(left);assert(left.listing.entries.size()==5000);left.move(4999);assert(left.scroll==4990);left.move(-4999);assert(left.scroll==0);
 std::ofstream(root/"grande.bin");fs::resize_file(root/"grande.bin",uint64_t(5)*1024*1024*1024);a=storage->list("/",stop);bool found=false;for(const auto&e:a.entries)if(e.name=="grande.bin"){assert(e.size==uint64_t(5)*1024*1024*1024);found=true;}assert(found);
 stop=true;assert(storage->list("/milhares",stop).error=="Leitura cancelada");
 left.up();finish(left);assert(left.path=="/");left.up();assert(!left.loading);
 fs::remove_all(root);std::cout<<"PASS: empty, 5000 entries, Unicode, >4 GiB, hidden, selection, panel isolation, scroll, invalid paths, symlink, read failure, cancellation, parent/root\n";
}
