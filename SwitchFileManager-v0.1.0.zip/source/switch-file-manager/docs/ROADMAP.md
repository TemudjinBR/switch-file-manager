# Evolução preservada

- **0.1:** dois painéis, microSD, navegação, seleção, controles, toque, compilação e testes.
- **0.2:** criar arquivos/pastas, copiar, recortar/colar, mover, renomear, duplicar, seleção total/invertida e renomeação em lote.
- **0.3:** confirmação de exclusão, proteção de diretórios, espaço disponível, conflitos substituir/ignorar/renomear, progresso por bytes, velocidade/ETA, fila, pausa/cancelamento seguros, histórico, recuperação e arquivos parciais.
- **0.4:** histórico voltar/avançar, favoritos, atalhos, ocultos configuráveis, ordenação completa, filtros, pesquisa recursiva, propriedades, SHA-256, comparação de arquivos/pastas, duplicados e tamanho de diretórios.
- **0.5:** USB OTG, dispositivos/partições, FAT12/16/32/exFAT/NTFS/EXT2/3/4 conforme comprovação, MBR/GPT, SD↔USB, capacidade, integridade, desconexão, ejeção e somente leitura quando necessário.
- **0.6:** instalador independente: NSP/XCI/NSZ/XCZ conforme validação; nome/versão/tamanho/jogo/atualização/DLC, duplicados e conflitos, fila/lote, progresso, espaço, cancelamento, destino e erros. Não apagar originais; não escrever na memória interna sem autorização.
- **0.7:** ZIP abrir/criar/extrair, 7z listar/extrair, RAR conforme licença, TAR/GZ/multipartes, extração seletiva e proteção contra caminhos maliciosos; TXT/INI/JSON/XML, imagens, hexadecimal e metadados; backup para edição e leitura eficiente de arquivos grandes.
- **0.8:** Android/PC↔Switch, interface web local, Wi-Fi, upload/download, pastas/lote, autenticação, pareamento por código/QR, descoberta, fila/progresso/recuperação; FTP e SFTP se viável; instalação remota e USB-PC conforme protocolos comprovados.
- **0.9:** Google Drive com autenticação apropriada, navegação, upload/download, criar/renomear/excluir, lote/progresso, falhas/renovação; instalação por download ou streaming se viável; contratos OneDrive/Dropbox/WebDAV; HTTP/HTTPS autenticado.
- **1.0:** otimização e validação no console; capacidade/uso/livre, análise por tipo, arquivos grandes/duplicados, alertas de espaço, diagnóstico de leitura/escrita, integridade e logs; idioma/tema/fontes/lista/detalhes/atalhos, preferências, configurações de rede/nuvem, importação/exportação/backup e histórico.

Todas as versões: testes de erros reais ou injetados, documentação de limitações e separação entre teste automatizado e físico. Reparos destrutivos nunca automáticos. Compatibilidade universal não prometida.
