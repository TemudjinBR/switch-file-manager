# Pesquisa técnica — 03/11/2026

## Dependências da v0.1

- libnx: https://github.com/switchbrew/libnx — APIs oficiais homebrew, entrada, toque, fonte compartilhada e devoptab SD.
- Exemplo SDL2/Makefile: https://github.com/switchbrew/switch-examples/tree/master/graphics/sdl2/sdl2-simple — base de configuração do toolchain; interface e lógica foram escritas do zero.
- Pacotes devkitPro: https://github.com/devkitPro/pacman-packages e https://pkg.devkitpro.org/packages/ — versões registradas em `dependencies.json`; arquivos baixados com SHA-256 e assinatura GPG verificados contra chave pública oficial.
- SDL2 e SDL2_ttf: https://github.com/libsdl-org/SDL/tree/SDL2 e https://github.com/libsdl-org/SDL_ttf — renderização e texto UTF-8, licença zlib.
- Borealis: https://github.com/natinusala/borealis — alternativa com foco em controles e UI acelerada, Apache-2.0. Avaliada, não incorporada. SDL2 escolhido para layout próprio e teste host com mesmo desenho; desempenho final requer console.
- CI: https://hub.docker.com/r/devkitpro/devkita64 — imagem oficial, com toolchain e portlibs. Tag explícita usada no workflow; ainda sem execução remota.

## USB — pesquisa preliminar, não implementação

Fonte: https://github.com/DarkMatterCore/libusbhsfs (README e licenças).

| Sistema | Biblioteca indicada | Situação nesta entrega |
|---|---|---|
| FAT12 | FatFs | suporte upstream; leitura/gravação no SFM não testadas |
| FAT16 | FatFs | suporte upstream; leitura/gravação no SFM não testadas |
| FAT32 | FatFs | suporte upstream; leitura/gravação USB no SFM não testadas |
| exFAT | FatFs | suporte upstream; leitura/gravação USB no SFM não testadas |
| NTFS | NTFS-3G | suporte upstream GPL; leitura/gravação no SFM não testadas |
| EXT2 | lwext4 | suporte upstream GPL; leitura/gravação no SFM não testadas |
| EXT3 | lwext4 | suporte upstream GPL; leitura/gravação no SFM não testadas |
| EXT4 | lwext4 | suporte upstream GPL; leitura/gravação no SFM não testadas |

O README declara os formatos, MBR/GPT/EBR/SFD, múltiplas unidades e ejeção. Isso não prova compatibilidade com cada dispositivo ou recurso do volume. Requer classe USB MSC, SCSI transparente e protocolo BOT; não se promete funcionamento com qualquer adaptador. NTFS tem limitações de journaling e EXT herda limites de lwext4. A variante ISC limita formatos; a variante completa introduz GPL. Antes da v0.5, validar por sistema de arquivos leitura, escrita, desconexão e comportamento somente leitura em mídia de teste descartável.

## Instalador — pesquisa preliminar, não implementação

- https://github.com/rashevskyv/dbi — referência funcional/documentação; nenhum código ou binário incorporado, nem presumida permissão para reutilização.
- https://github.com/mrbeige1/open-dbi — declara reconstrução clean-room; arquivo LICENSE consultado usa Unlicense. Não incorporado. A descrição de suporte não foi tratada como comprovação de implementação completa ou segura.

NSP/XCI/NSZ/XCZ, metadados, instalação, streaming e protocolos serão avaliados individualmente na v0.6. Nenhum parser ou instalador foi declarado pronto nesta entrega. Não foram obtidas chaves, nem implementados mecanismos para contornar licenças.
