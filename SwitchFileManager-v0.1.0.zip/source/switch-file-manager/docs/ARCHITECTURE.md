# Arquitetura — v0.1

Código novo, sem importação dos projetos anteriores. C++17.

- `Storage`: contrato de listagem cancelável, resultado com erros e capacidade.
- `LocalStorage`: implementação POSIX para microSD (`sdmc:`); desktop usa diretório de teste. Não expõe operações de escrita.
- `Panel`: caminho, cursor, rolagem e seleção independentes; resultado de leitura transferido por `future` para a thread principal.
- `Ui`: renderização SDL2 + SDL2_ttf em 1280 × 720; sem chamadas ao armazenamento.
- `main`: ciclo de eventos; adaptação libnx para controles e toque; fonte compartilhada do console, sem distribuição de fontes Nintendo.
- `tests`: núcleo portátil compilado com sanitizadores; validação estrutural do NRO separada.

Uma leitura por painel. Durante a leitura, entradas de navegação desse painel são ignoradas para evitar resultados fora de ordem. O outro painel continua utilizável. Ao falhar, a pasta anterior permanece visível com mensagem de erro. A saída solicita cancelamento e aguarda a thread; uma chamada de sistema bloqueada pode atrasar a saída.

Pastas ordenadas antes dos arquivos; nomes ordenados por bytes UTF-8, sem colação linguística. Links simbólicos não aparecem. Não se presume que esta validação de caminhos possa servir, sem reforço, a operações futuras de escrita ou a servidores de rede.

## Contratos para as próximas versões

Módulos futuros não estão implementados nem são simulados por botões:

| Módulo | Responsabilidade e limite |
|---|---|
| Operações + segurança | planos de cópia/movimentação; confirmação; proteção de diretórios; arquivos temporários e conclusão atômica quando suportada |
| Fila | progresso por bytes; estados pendente/executando/pausado/cancelado/falha/concluído; nenhuma conclusão com erro pendente |
| USB | enumeração, capacidades por volume, ejeção e desconexão; libusbhsfs isolada do núcleo |
| Instalador | identificação e validação primeiro; gravação independente e explicitamente autorizada; sem chaves ou distribuição de conteúdo |
| Rede + nuvem | provedor por URI, autenticação fora do código, capacidades explícitas e renovação de credenciais |
| Compactados | validação de caminho e limites de expansão antes de extração |
| Visualizadores | leitura paginada; editores com backup e confirmação |
| Configurações | esquema versionado e validação de importação |
| Diagnóstico | eventos estruturados sem tokens, credenciais ou conteúdo privado |

Cada provedor futuro deverá declarar leitura, escrita, renomeação, seek, espaço livre e cancelamento. Uma operação só poderá ser oferecida se todas as capacidades necessárias estiverem disponíveis.
