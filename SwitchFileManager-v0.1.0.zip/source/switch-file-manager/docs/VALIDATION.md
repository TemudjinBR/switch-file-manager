# Validação — 03/11/2026

## Executado

| Verificação | Resultado e limite |
|---|---|
| Compilação Switch | Sucesso; devkitA64 GCC 16.1.0, libnx 4.12.0; `-Wall -Wextra -Werror`; sem avisos |
| Arquitetura ELF | AArch64, ELF64, executável independente de posição |
| NRO | NRO0, segmentos e assets ASET dentro dos limites; 8.440.005 bytes |
| Testes do núcleo | PASS, GCC host com AddressSanitizer e UndefinedBehaviorSanitizer |
| LeakSanitizer | Desativado nesta execução porque o sandbox impede leitura de `/proc/.../task`; não alegado teste de vazamentos |
| Interface | Mesmo código SDL2 compilado no Linux com `-Werror`, executado em driver dummy; captura 1280 × 720 revisada |
| Pastas vazias | Teste automatizado: cursor/seleção/abrir sem item não falham |
| Milhares de itens | 5.000 arquivos; listagem e limites de rolagem verificados |
| Arquivo grande | Arquivo esparso de 5 GiB; tamanho lido corretamente; não é teste de transferência |
| UTF-8 | Pasta `ação 日本語` preservada no núcleo; cobertura visual completa depende da fonte |
| Independência | Caminho, seleção e rolagem dos painéis separados |
| Erros | Caminho inexistente; erro de permissão e exceção injetados; listagem anterior preservada |
| Segurança de leitura | Rejeição de `..`, caminhos relativos, NUL e barra invertida; links omitidos |
| Cancelamento | Provedor cancela varredura; não há operação de escrita para cancelar |
| Assinaturas de dependências | SHA-256 e assinatura GPG de cada pacote extraído verificados |

Logs em `evidence/`. Imagem `preview.png` é do aplicativo executado no desktop com arquivos de teste, não uma captura do console.

## Ainda não executado

- Inicialização e retorno ao Homebrew Menu no Switch Lite/Atmosphère.
- Controles físicos, touchscreen, legibilidade da fonte, memória, CPU e fluidez no console.
- Modo applet, retirada de cartão e erros reais do microSD.
- Compilação no GitHub Actions: acesso remoto pendente.
- USB/desconexão, Wi-Fi/perda de rede, escrita/falta de espaço/conflitos, compactados inválidos, instaláveis inválidos/interrupção, autenticação de nuvem: módulos fora da v0.1, sem alegação de testes.

## Roteiro físico de aceitação

1. Abrir no Homebrew Menu em modo aplicativo; confirmar imagem, fonte e listagem.
2. Usar A/B para abrir/subir, − para raiz e L/R para trocar painel.
3. Abrir pastas diferentes; confirmar que o painel inativo mantém seu caminho.
4. Marcar itens com X; mover cursor e confirmar marcações; trocar painel sem misturar seleção.
5. Em pasta com muitos itens, testar direcional mantido e ZL/ZR.
6. Testar toque nas linhas e ações inferiores, nomes longos e caracteres acentuados.
7. Atualizar com Y; sair com +; confirmar retorno sem travamento.

Nenhum teste físico foi inventado. A v0.1 deve ser tratada como versão inicial para validação, não versão estável final.
