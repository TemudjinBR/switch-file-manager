# Licenças e atribuições

Código original Switch File Manager: MIT, arquivo `LICENSE`.

- libnx: licença ISC, copyright dos autores; texto em `licenses/libnx.txt`.
- SDL2 e SDL2_ttf: zlib; textos em `licenses/`.
- FreeType: usada sob FreeType License (FTL); este software utiliza FreeType, copyright The FreeType Project (www.freetype.org). Textos FTL/LICENSE incluídos; cópia GPL fornecida pelo pacote não significa escolha da opção GPL para esta v0.1.
- HarfBuzz: licença permissiva, copyright autores; `licenses/harfbuzz.txt`.
- libpng, zlib, bzip2: licenças permissivas próprias, textos incluídos.
- Mesa e libdrm_nouveau: componentes do backend SDL Switch; licenças permissivas e avisos em `licenses/`.
- devkitA64 e ferramentas: usadas para compilação, não redistribuídas no pacote. Runtime newlib/libstdc++ mantém condições e exceções de runtime próprias.
- Makefile segue a estrutura pública do exemplo SDL2 do switchbrew/switch-examples; código gráfico, navegação e modelo escritos para este projeto.

Borealis, DBI, open-dbi e libusbhsfs não estão vinculados ou incluídos nesta versão. A futura variante completa libusbhsfs/NTFS/EXT exige distribuição combinada compatível com GPL, mantendo as atribuições do código original MIT. Avaliar antes da integração; não incorporar dependências incompatíveis silenciosamente.

Não são distribuídas fontes Nintendo; a API de fonte compartilhada é usada no console. Não são distribuídos jogos, chaves ou arquivos de firmware.
