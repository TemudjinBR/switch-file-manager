# Changelog

## 0.1.0 — 2026-11-03

- Fundação nova em C++17, sem reaproveitar o projeto anterior.
- Dois painéis SDL2, navegação assíncrona, seleção múltipla e rolagem.
- Controles libnx, touchscreen e fonte compartilhada do console.
- Provedor microSD somente leitura, erros e capacidade.
- Build NRO real, validador estrutural, testes ASan/UBSan e workflow CI.
- Teste físico no console e publicação remota pendentes.
