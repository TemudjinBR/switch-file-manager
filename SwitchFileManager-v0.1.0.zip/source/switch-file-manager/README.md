# Switch File Manager — v0.1.0

Gerenciador homebrew novo em C++17 para Nintendo Switch, com prioridade ao Switch Lite e Atmosphère. Interface original de dois painéis em azul-marinho/ciano.

**Estado:** NRO compilado e validado estruturalmente em 03/11/2026. Núcleo e interface desktop executados. Ainda não testado em console físico. Não é uma versão 1.0 estável.

![Interface real executada no desktop, com uma pasta de teste](docs/preview.png)

## Usar no console

1. Extraia a pasta `switch` do pacote na raiz do microSD.
2. Abra o Homebrew Menu e execute **Switch File Manager**.
3. Para teste inicial, use o modo aplicativo do Homebrew Menu. O modo applet ainda não foi validado.

O NRO usa a fonte compartilhada do sistema. Não exige arquivos de fonte nem acesso à Internet. Esta versão só lê o microSD; não copia, exclui ou instala conteúdos. Nenhuma gravação em armazenamento interno foi implementada.

## Controles

| Ação | Switch | Desktop de teste |
|---|---|---|
| Navegar | direcional ou analógico esquerdo | ↑ / ↓ |
| Abrir pasta | A | Enter |
| Subir um nível | B | Backspace |
| Trocar painel | L ou R | Tab |
| Marcar/desmarcar item | X | Espaço |
| Atualizar | Y | F5 |
| Raiz | − | Home |
| Página anterior/seguinte | ZL / ZR | PageUp / PageDown |
| Sair | + | Esc |

Toque: toque em um painel para ativá-lo; toque em um item para focar e novamente para abrir uma pasta. A barra inferior permite executar as ações por toque. A seleção é independente em cada painel. A coluna corta nomes longos com reticências; o nome completo do item focado e o caminho longo rolam horizontalmente.

## Implementado

- Dois painéis independentes; destaque do ativo; pastas e arquivos reais.
- Navegação microSD, raiz/subir, cursor, rolagem e seleção múltipla.
- Colunas nome/tamanho/tipo/data, ícones, capacidade e espaço livre.
- Leitura assíncrona: a interface permanece disponível enquanto a pasta é carregada.
- Pastas antes dos arquivos; UTF-8; ocultos visíveis; nomes completos preservados no núcleo.
- Erros sem substituir a listagem anterior; links simbólicos omitidos.
- Makefile devkitPro, testes host, verificação NRO e fluxo GitHub Actions.

## Compilar

Ambiente oficial devkitPro com `devkitA64`, `libnx`, `switch-tools`, `devkita64-rules`, `switch-sdl2`, `switch-sdl2_ttf` e dependências transitivas.

```sh
export DEVKITPRO=/opt/devkitpro
export DEVKITA64=$DEVKITPRO/devkitA64
export PATH=$DEVKITA64/bin:$DEVKITPRO/tools/bin:$DEVKITPRO/portlibs/switch/bin:$PATH
make -j2
python3 scripts/verify_nro.py SwitchFileManager.nro
```

Saída: `SwitchFileManager.nro`. Versões realmente usadas: `docs/dependencies.json`.

Teste desktop Linux: `make -f Makefile.host test`; com SDL2/SDL2_ttf de desenvolvimento instalados, `make -f Makefile.host desktop` e `./build-host/preview /pasta/de/teste`. Essa versão é apenas um harness de teste do mesmo núcleo e desenho, não um simulador do Switch.

A definição de GitHub Actions compila em push/PR/execução manual, guarda artefato e prepara release em rascunho para tags `v*`. **O fluxo está escrito, mas ainda não foi executado no GitHub: o repositório remoto não foi criado por bloqueio de acesso.** O repositório `switch-manager` não foi alterado.

## Limitações

Sem edição/transferência, USB, rede, nuvem, instalador ou compactados nesta etapa. Esses módulos estão preservados em `docs/ROADMAP.md`. Não há promessa de compatibilidade universal USB. Ordenação por bytes UTF-8, sem ordenação linguística. Cobertura visual de caracteres depende da fonte do console. Data usa a hora fornecida pelo sistema de arquivos. Memória e tempo no console ainda precisam ser medidos.

Licença do código original: MIT. Dependências mantêm suas licenças; leia `docs/THIRD_PARTY.md`. O suporte futuro a NTFS/EXT exige rever a licença de distribuição combinada.
